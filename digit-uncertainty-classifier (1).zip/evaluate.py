"""Evaluate baseline and uncertainty-aware behavior.

This script reports:
- normal test accuracy on clean MNIST,
- selective accuracy after abstaining on high-uncertainty samples,
- rejection rate on random noise,
- rejection rate on corrupted/ambiguous digits.

Example:
    python evaluate.py --checkpoint checkpoints/model.pt --auto-threshold
"""

from __future__ import annotations

import argparse
from pathlib import Path

import torch

from src.data import corrupt_digits, get_mnist_loaders, make_random_noise_like
from src.model import DigitCNN
from src.uncertainty import mc_dropout_predict, summarize_selective_metrics
from src.utils import get_device, load_checkpoint, save_json, set_seed


@torch.no_grad()
def collect_uncertainty_scores(model, loader, device, repeats, max_batches, transform_kind="clean"):
    scores = []
    for batch_index, (images, _targets) in enumerate(loader):
        if max_batches is not None and batch_index >= max_batches:
            break
        images = images.to(device)
        if transform_kind == "noise":
            images = make_random_noise_like(images)
        elif transform_kind == "corrupt":
            images = corrupt_digits(images)
        output = mc_dropout_predict(model, images, repeats=repeats, threshold=10**9)
        scores.append(output.uncertainty_score.detach().cpu())
    return torch.cat(scores)


def auto_calibrate_threshold(model, val_loader, device, repeats, max_batches):
    """Pick a threshold from validation data.

    The rule uses the 95th percentile of clean validation uncertainty. This means the model
    should keep about 95 percent of normal clean digits while rejecting examples that are
    more uncertain than almost all clean validation images.
    """
    clean_scores = collect_uncertainty_scores(model, val_loader, device, repeats, max_batches, "clean")
    threshold = torch.quantile(clean_scores, 0.95).item()
    return threshold


def evaluate_clean(model, loader, device, repeats, threshold, max_batches):
    all_predictions = []
    all_targets = []
    all_uncertain = []
    all_scores = []

    for batch_index, (images, targets) in enumerate(loader):
        if max_batches is not None and batch_index >= max_batches:
            break
        images, targets = images.to(device), targets.to(device)
        output = mc_dropout_predict(model, images, repeats=repeats, threshold=threshold)
        all_predictions.append(output.prediction.cpu())
        all_targets.append(targets.cpu())
        all_uncertain.append(output.is_uncertain.cpu())
        all_scores.append(output.uncertainty_score.cpu())

    predictions = torch.cat(all_predictions)
    targets = torch.cat(all_targets)
    is_uncertain = torch.cat(all_uncertain)
    scores = torch.cat(all_scores)
    return summarize_selective_metrics(predictions, targets, is_uncertain, scores)


def evaluate_rejection(model, loader, device, repeats, threshold, max_batches, kind):
    total = 0
    rejected = 0
    score_sum = 0.0

    for batch_index, (images, _targets) in enumerate(loader):
        if max_batches is not None and batch_index >= max_batches:
            break
        images = images.to(device)
        if kind == "noise":
            images = make_random_noise_like(images)
        elif kind == "corrupt":
            images = corrupt_digits(images)
        else:
            raise ValueError("kind must be 'noise' or 'corrupt'")

        output = mc_dropout_predict(model, images, repeats=repeats, threshold=threshold)
        total += images.size(0)
        rejected += output.is_uncertain.sum().item()
        score_sum += output.uncertainty_score.sum().item()

    return {
        "count": total,
        "rejection_rate": rejected / total if total else 0.0,
        "avg_uncertainty": score_sum / total if total else 0.0,
    }


def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate MNIST uncertainty-aware classifier.")
    parser.add_argument("--checkpoint", default="checkpoints/model.pt", help="Path to saved model checkpoint.")
    parser.add_argument("--data-dir", default="data", help="Directory for MNIST data.")
    parser.add_argument("--batch-size", type=int, default=128, help="Batch size.")
    parser.add_argument("--repeats", type=int, default=30, help="Monte Carlo Dropout forward passes.")
    parser.add_argument("--threshold", type=float, default=0.02, help="Variance threshold for UNCERTAIN.")
    parser.add_argument("--auto-threshold", action="store_true", help="Choose threshold from validation uncertainty.")
    parser.add_argument("--max-batches", type=int, default=30, help="Limit batches for faster evaluation. Use 0 for all.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, or mps if available.")
    parser.add_argument("--num-workers", type=int, default=2, help="DataLoader workers.")
    return parser.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)
    device = get_device(args.device)
    max_batches = None if args.max_batches == 0 else args.max_batches

    _train_loader, val_loader, test_loader = get_mnist_loaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        seed=args.seed,
        num_workers=args.num_workers,
    )

    model = DigitCNN().to(device)
    checkpoint = load_checkpoint(args.checkpoint, model, device)
    if "dropout" in checkpoint:
        # Rebuild with the same dropout value used during training.
        model = DigitCNN(dropout_p=float(checkpoint["dropout"])).to(device)
        load_checkpoint(args.checkpoint, model, device)

    threshold = args.threshold
    if args.auto_threshold:
        threshold = auto_calibrate_threshold(model, val_loader, device, args.repeats, max_batches)
        print(f"Auto-calibrated threshold: {threshold:.6f}")

    clean_metrics = evaluate_clean(model, test_loader, device, args.repeats, threshold, max_batches)
    noise_metrics = evaluate_rejection(model, test_loader, device, args.repeats, threshold, max_batches, "noise")
    corrupt_metrics = evaluate_rejection(model, test_loader, device, args.repeats, threshold, max_batches, "corrupt")

    results = {
        "checkpoint": str(Path(args.checkpoint)),
        "mc_dropout_repeats": args.repeats,
        "threshold": threshold,
        "clean_mnist": clean_metrics,
        "random_noise": noise_metrics,
        "corrupted_digits": corrupt_metrics,
    }
    save_json(results, "results/evaluation.json")

    print("\nEvaluation summary")
    print("------------------")
    print(f"Clean accuracy, all predictions: {clean_metrics['accuracy_all']:.4f}")
    print(f"Coverage on clean digits:        {clean_metrics['coverage']:.4f}")
    print(f"Selective accuracy accepted:     {clean_metrics['selective_accuracy_on_accepted']:.4f}")
    print(f"Clean rejection rate:            {clean_metrics['rejection_rate']:.4f}")
    print(f"Noise rejection rate:            {noise_metrics['rejection_rate']:.4f}")
    print(f"Corrupt rejection rate:          {corrupt_metrics['rejection_rate']:.4f}")
    print("Saved results to results/evaluation.json")


if __name__ == "__main__":
    main()
