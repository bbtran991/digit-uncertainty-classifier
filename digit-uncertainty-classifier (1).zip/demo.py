"""Run a simple demo for one image.

Examples:
    python demo.py --checkpoint checkpoints/model.pt --sample clean --index 7
    python demo.py --checkpoint checkpoints/model.pt --sample noise
    python demo.py --checkpoint checkpoints/model.pt --sample corrupt --index 7
    python demo.py --checkpoint checkpoints/model.pt --image my_digit.png
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import torch
from PIL import Image

from src.data import MNIST_MEAN, MNIST_STD, corrupt_digits, denormalize_image, get_mnist_loaders, make_random_noise_like, normalize_image
from src.model import DigitCNN
from src.uncertainty import mc_dropout_predict
from src.utils import get_device, load_checkpoint, set_seed


def preprocess_external_image(path: str | Path, invert: str = "auto") -> torch.Tensor:
    """Load an outside image and convert it to normalized MNIST format.

    MNIST uses light digits on a dark background. If a user image has dark writing on a
    light background, auto inversion usually fixes it.
    """
    image = Image.open(path).convert("L").resize((28, 28))
    tensor = torch.tensor(list(image.getdata()), dtype=torch.float32).view(1, 28, 28) / 255.0

    if invert == "yes" or (invert == "auto" and tensor.mean().item() > 0.5):
        tensor = 1.0 - tensor

    return normalize_image(tensor).unsqueeze(0)


def choose_sample(args, device):
    if args.image:
        image = preprocess_external_image(args.image, args.invert)
        true_label = "unknown external image"
        title = f"External image: {args.image}"
        return image.to(device), true_label, title

    _train_loader, _val_loader, test_loader = get_mnist_loaders(
        data_dir=args.data_dir,
        batch_size=max(args.index + 1, 32),
        seed=args.seed,
        num_workers=args.num_workers,
    )
    images, targets = next(iter(test_loader))
    image = images[args.index : args.index + 1]
    target = int(targets[args.index].item())

    if args.sample == "noise":
        image = make_random_noise_like(image)
        true_label = "random noise"
    elif args.sample == "corrupt":
        image = corrupt_digits(image)
        true_label = f"corrupted version of digit {target}"
    else:
        true_label = str(target)

    return image.to(device), true_label, f"Sample type: {args.sample}"


def save_demo_plot(image, output, true_label, title, output_path):
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    display_image = denormalize_image(image.detach().cpu()[0]).squeeze(0)
    probs = output.mean_probs.detach().cpu()[0]

    fig = plt.figure(figsize=(8, 4))

    ax1 = fig.add_axes([0.08, 0.18, 0.28, 0.68])
    ax1.imshow(display_image, cmap="gray")
    ax1.set_title(title)
    ax1.axis("off")

    ax2 = fig.add_axes([0.45, 0.18, 0.48, 0.68])
    ax2.bar(range(10), probs.numpy())
    ax2.set_xticks(range(10))
    ax2.set_xlabel("Digit")
    ax2.set_ylabel("Mean probability")
    ax2.set_ylim(0.0, 1.0)
    ax2.set_title("MC Dropout mean probabilities")

    decision = output.final_label[0]
    fig.suptitle(
        f"True/input: {true_label} | Decision: {decision} | "
        f"Uncertainty: {output.uncertainty_score[0].item():.5f}"
    )
    fig.savefig(output_path, bbox_inches="tight", dpi=160)
    plt.close(fig)


def parse_args():
    parser = argparse.ArgumentParser(description="Demo uncertainty-aware digit classifier.")
    parser.add_argument("--checkpoint", default="checkpoints/model.pt", help="Path to trained model checkpoint.")
    parser.add_argument("--data-dir", default="data", help="Directory for MNIST data.")
    parser.add_argument("--sample", choices=["clean", "corrupt", "noise"], default="clean", help="Built-in sample type.")
    parser.add_argument("--image", default=None, help="Optional path to your own digit image.")
    parser.add_argument("--invert", choices=["auto", "yes", "no"], default="auto", help="Invert external image colors.")
    parser.add_argument("--index", type=int, default=0, help="MNIST test-set index for clean/corrupt samples.")
    parser.add_argument("--repeats", type=int, default=30, help="Monte Carlo Dropout forward passes.")
    parser.add_argument("--threshold", type=float, default=0.02, help="Variance threshold for UNCERTAIN.")
    parser.add_argument("--save", default="results/demo_output.png", help="Where to save the visualization.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, or mps if available.")
    parser.add_argument("--num-workers", type=int, default=2, help="DataLoader workers.")
    return parser.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)
    device = get_device(args.device)

    model = DigitCNN().to(device)
    checkpoint = load_checkpoint(args.checkpoint, model, device)
    if "dropout" in checkpoint:
        model = DigitCNN(dropout_p=float(checkpoint["dropout"])).to(device)
        load_checkpoint(args.checkpoint, model, device)

    image, true_label, title = choose_sample(args, device)
    output = mc_dropout_predict(model, image, repeats=args.repeats, threshold=args.threshold)

    # Baseline prediction: one normal forward pass, no abstention.
    model.eval()
    with torch.no_grad():
        baseline_digit = model(image).argmax(dim=1).item()

    print("Demo result")
    print("-----------")
    print(f"Input label/type:       {true_label}")
    print(f"Baseline CNN predicts:  {baseline_digit}")
    print(f"MC mean prediction:     {output.prediction[0].item()}")
    print(f"Confidence:             {output.confidence[0].item():.5f}")
    print(f"Uncertainty score:      {output.uncertainty_score[0].item():.5f}")
    print(f"Entropy:                {output.entropy[0].item():.5f}")
    print(f"Margin top1-top2:       {output.margin[0].item():.5f}")
    print(f"Final decision:         {output.final_label[0]}")

    save_demo_plot(image, output, true_label, title, args.save)
    print(f"Saved visualization to {args.save}")


if __name__ == "__main__":
    main()
