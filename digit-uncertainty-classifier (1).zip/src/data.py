"""Dataset helpers for MNIST and uncertainty stress tests."""

from __future__ import annotations

from pathlib import Path
from typing import Tuple

import torch
from torch.utils.data import DataLoader, random_split

MNIST_MEAN = 0.1307
MNIST_STD = 0.3081


def get_mnist_loaders(
    data_dir: str | Path = "data",
    batch_size: int = 128,
    val_size: int = 5000,
    seed: int = 42,
    num_workers: int = 2,
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """Return train, validation, and test DataLoaders.

    The first run downloads MNIST into data_dir. Later runs reuse the local copy.
    """
    from torchvision import datasets, transforms

    transform = transforms.Compose(
        [
            transforms.ToTensor(),
            transforms.Normalize((MNIST_MEAN,), (MNIST_STD,)),
        ]
    )

    data_dir = Path(data_dir)
    full_train = datasets.MNIST(data_dir, train=True, download=True, transform=transform)
    test_set = datasets.MNIST(data_dir, train=False, download=True, transform=transform)

    train_size = len(full_train) - val_size
    generator = torch.Generator().manual_seed(seed)
    train_set, val_set = random_split(full_train, [train_size, val_size], generator=generator)

    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    test_loader = DataLoader(test_set, batch_size=batch_size, shuffle=False, num_workers=num_workers)
    return train_loader, val_loader, test_loader


def normalize_image(x: torch.Tensor) -> torch.Tensor:
    """Normalize an image tensor in [0, 1] with MNIST statistics."""
    return (x - MNIST_MEAN) / MNIST_STD


def denormalize_image(x: torch.Tensor) -> torch.Tensor:
    """Convert normalized MNIST tensor back to approximately [0, 1]."""
    return (x * MNIST_STD + MNIST_MEAN).clamp(0.0, 1.0)


def make_random_noise_like(batch: torch.Tensor) -> torch.Tensor:
    """Create out-of-distribution random noise images with the same shape as batch."""
    noise = torch.rand_like(batch)
    return normalize_image(noise)


def corrupt_digits(batch: torch.Tensor, noise_std: float = 0.45, erase_size: int = 10) -> torch.Tensor:
    """Create ambiguous/corrupted digit-like inputs.

    This simulates the scribbles and partial strokes described in the project proposal by:
    - adding Gaussian noise,
    - randomly erasing one square patch from each image,
    - keeping the same 28 x 28 MNIST format.
    """
    x = denormalize_image(batch.clone())
    x = (x + torch.randn_like(x) * noise_std).clamp(0.0, 1.0)

    batch_size = x.shape[0]
    height, width = x.shape[-2:]
    for i in range(batch_size):
        top = torch.randint(0, max(1, height - erase_size + 1), (1,)).item()
        left = torch.randint(0, max(1, width - erase_size + 1), (1,)).item()
        x[i, :, top : top + erase_size, left : left + erase_size] = 0.0

    return normalize_image(x)
