"""Digit classifier that knows when it is unsure."""
