"""CNN model for MNIST digit classification with dropout layers.

The dropout layers are used twice:
1. During training, they regularize the model.
2. During inference, Monte Carlo Dropout keeps them active to estimate uncertainty.
"""

from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F


class DigitCNN(nn.Module):
    """Small convolutional neural network for 28 x 28 grayscale MNIST images."""

    def __init__(self, dropout_p: float = 0.5) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.dropout2d = nn.Dropout2d(p=0.25)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.dropout = nn.Dropout(p=dropout_p)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))  # 28x28 -> 14x14
        x = self.pool(F.relu(self.conv2(x)))  # 14x14 -> 7x7
        x = self.dropout2d(x)
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        return self.fc2(x)
