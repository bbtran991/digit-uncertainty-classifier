"""Monte Carlo Dropout inference and selective prediction."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

import torch
from torch import nn
import torch.nn.functional as F


@dataclass
class UncertaintyOutput:
    prediction: torch.Tensor
    final_label: list[str]
    uncertainty_score: torch.Tensor
    confidence: torch.Tensor
    entropy: torch.Tensor
    margin: torch.Tensor
    mean_probs: torch.Tensor
    var_probs: torch.Tensor
    is_uncertain: torch.Tensor


def enable_dropout_for_inference(model: nn.Module) -> None:
    """Keep only dropout layers in train mode while the rest of the model stays in eval mode."""
    for module in model.modules():
        if isinstance(module, (nn.Dropout, nn.Dropout2d, nn.Dropout3d, nn.AlphaDropout)):
            module.train()


def mc_dropout_predict(
    model: nn.Module,
    images: torch.Tensor,
    repeats: int = 30,
    threshold: float = 0.02,
) -> UncertaintyOutput:
    """Predict with Monte Carlo Dropout.

    Args:
        model: Trained CNN containing dropout layers.
        images: Tensor with shape [batch, 1, 28, 28].
        repeats: Number of stochastic forward passes. The proposal used 30.
        threshold: If max predictive variance is above this value, output UNCERTAIN.

    Returns:
        UncertaintyOutput with prediction, uncertainty score, confidence, entropy,
        probability variance, and final label.
    """
    if images.ndim != 4:
        raise ValueError("images must have shape [batch, channels, height, width]")

    model.eval()
    enable_dropout_for_inference(model)

    probs = []
    with torch.no_grad():
        for _ in range(repeats):
            logits = model(images)
            probs.append(F.softmax(logits, dim=1))

    stacked = torch.stack(probs, dim=0)  # [repeats, batch, classes]
    mean_probs = stacked.mean(dim=0)
    var_probs = stacked.var(dim=0, unbiased=False)

    confidence, prediction = mean_probs.max(dim=1)
    uncertainty_score = var_probs.max(dim=1)
    entropy = -(mean_probs * (mean_probs + 1e-8).log()).sum(dim=1)

    top2 = torch.topk(mean_probs, k=2, dim=1).values
    margin = top2[:, 0] - top2[:, 1]

    is_uncertain = uncertainty_score > threshold
    final_label = ["UNCERTAIN" if flag else str(pred.item()) for flag, pred in zip(is_uncertain, prediction)]

    return UncertaintyOutput(
        prediction=prediction,
        final_label=final_label,
        uncertainty_score=uncertainty_score,
        confidence=confidence,
        entropy=entropy,
        margin=margin,
        mean_probs=mean_probs,
        var_probs=var_probs,
        is_uncertain=is_uncertain,
    )


def summarize_selective_metrics(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    is_uncertain: torch.Tensor,
    uncertainty_score: torch.Tensor,
) -> Dict[str, float]:
    """Compute accuracy, coverage, selective accuracy, and uncertainty summaries."""
    correct = predictions.eq(targets)
    accepted = ~is_uncertain

    accuracy = correct.float().mean().item()
    coverage = accepted.float().mean().item()
    rejection_rate = is_uncertain.float().mean().item()

    if accepted.any():
        selective_accuracy = correct[accepted].float().mean().item()
    else:
        selective_accuracy = 0.0

    if correct.any():
        avg_uncertainty_correct = uncertainty_score[correct].mean().item()
    else:
        avg_uncertainty_correct = 0.0

    if (~correct).any():
        avg_uncertainty_wrong = uncertainty_score[~correct].mean().item()
    else:
        avg_uncertainty_wrong = 0.0

    return {
        "accuracy_all": accuracy,
        "coverage": coverage,
        "rejection_rate": rejection_rate,
        "selective_accuracy_on_accepted": selective_accuracy,
        "avg_uncertainty_correct": avg_uncertainty_correct,
        "avg_uncertainty_wrong": avg_uncertainty_wrong,
    }
