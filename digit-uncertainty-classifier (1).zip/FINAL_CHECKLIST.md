# Final Project Submission Checklist

Use this checklist before submitting the GitHub link.

## Required by assignment

- [ ] Code for the final project is included.
- [ ] README explains how to run the code.
- [ ] README lists required packages/dependencies.
- [ ] README explains where the main training, inference, and demo code is located.
- [ ] The project matches the proposed idea: MNIST classifier with uncertainty/abstention.
- [ ] The repository is organized and readable.
- [ ] The code can be run from a clean setup.
- [ ] You understand the code enough to explain it.

## Suggested commands to run before submitting

```bash
pip install -r requirements.txt
python train.py --epochs 5 --batch-size 128
python evaluate.py --checkpoint checkpoints/model.pt --auto-threshold
python demo.py --checkpoint checkpoints/model.pt --sample clean --index 0
python demo.py --checkpoint checkpoints/model.pt --sample corrupt --index 0
python demo.py --checkpoint checkpoints/model.pt --sample noise
```

## What to explain if asked

- A baseline CNN always predicts one digit.
- The uncertainty-aware model runs 30 dropout-enabled forward passes.
- It averages probabilities to choose the digit.
- It uses variance across predictions as the uncertainty score.
- If variance is above the threshold, the model outputs `UNCERTAIN`.
- Random noise and corrupted digits should usually have higher uncertainty than clean digits.
