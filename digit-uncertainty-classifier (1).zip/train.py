"""Train the CNN on MNIST and save a checkpoint.

Example:
    python train.py --epochs 5 --batch-size 128
"""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch import nn, optim
import torch.nn.functional as F

from src.data import get_mnist_loaders
from src.model import DigitCNN
from src.utils import get_device, save_json, set_seed


def run_one_epoch(model, loader, optimizer, device):
    model.train()
    total_loss = 0.0
    total_correct = 0
    total_seen = 0

    for images, targets in loader:
        images, targets = images.to(device), targets.to(device)

        optimizer.zero_grad()
        logits = model(images)
        loss = F.cross_entropy(logits, targets)
        loss.backward()
        optimizer.step()

        batch_size = images.size(0)
        total_loss += loss.item() * batch_size
        total_correct += logits.argmax(dim=1).eq(targets).sum().item()
        total_seen += batch_size

    return {
        "loss": total_loss / total_seen,
        "accuracy": total_correct / total_seen,
    }


@torch.no_grad()
def evaluate_accuracy(model, loader, device):
    model.eval()
    total_loss = 0.0
    total_correct = 0
    total_seen = 0

    for images, targets in loader:
        images, targets = images.to(device), targets.to(device)
        logits = model(images)
        loss = F.cross_entropy(logits, targets)

        batch_size = images.size(0)
        total_loss += loss.item() * batch_size
        total_correct += logits.argmax(dim=1).eq(targets).sum().item()
        total_seen += batch_size

    return {
        "loss": total_loss / total_seen,
        "accuracy": total_correct / total_seen,
    }


def parse_args():
    parser = argparse.ArgumentParser(description="Train an MNIST CNN with dropout.")
    parser.add_argument("--data-dir", default="data", help="Directory for MNIST data.")
    parser.add_argument("--out-dir", default="checkpoints", help="Directory for saved model checkpoints.")
    parser.add_argument("--epochs", type=int, default=5, help="Number of training epochs.")
    parser.add_argument("--batch-size", type=int, default=128, help="Batch size.")
    parser.add_argument("--lr", type=float, default=1e-3, help="Learning rate.")
    parser.add_argument("--dropout", type=float, default=0.5, help="Dropout probability in the fully connected layer.")
    parser.add_argument("--val-size", type=int, default=5000, help="Validation examples split from training set.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, or mps if available.")
    parser.add_argument("--num-workers", type=int, default=2, help="DataLoader workers.")
    return parser.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)
    device = get_device(args.device)
    print(f"Using device: {device}")

    train_loader, val_loader, test_loader = get_mnist_loaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        val_size=args.val_size,
        seed=args.seed,
        num_workers=args.num_workers,
    )

    model = DigitCNN(dropout_p=args.dropout).to(device)
    optimizer = optim.Adam(model.parameters(), lr=args.lr)

    history = []
    best_val_acc = -1.0
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    best_path = out_dir / "model.pt"

    for epoch in range(1, args.epochs + 1):
        train_metrics = run_one_epoch(model, train_loader, optimizer, device)
        val_metrics = evaluate_accuracy(model, val_loader, device)

        row = {
            "epoch": epoch,
            "train_loss": train_metrics["loss"],
            "train_accuracy": train_metrics["accuracy"],
            "val_loss": val_metrics["loss"],
            "val_accuracy": val_metrics["accuracy"],
        }
        history.append(row)
        print(
            f"Epoch {epoch:02d} | "
            f"train loss {row['train_loss']:.4f}, train acc {row['train_accuracy']:.4f} | "
            f"val loss {row['val_loss']:.4f}, val acc {row['val_accuracy']:.4f}"
        )

        if val_metrics["accuracy"] > best_val_acc:
            best_val_acc = val_metrics["accuracy"]
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "dropout": args.dropout,
                    "epoch": epoch,
                    "val_accuracy": best_val_acc,
                    "args": vars(args),
                },
                best_path,
            )

    # Load best checkpoint and report test accuracy.
    checkpoint = torch.load(best_path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    test_metrics = evaluate_accuracy(model, test_loader, device)

    final_metrics = {
        "best_checkpoint": str(best_path),
        "best_val_accuracy": best_val_acc,
        "test_accuracy": test_metrics["accuracy"],
        "test_loss": test_metrics["loss"],
        "history": history,
    }
    save_json(final_metrics, "results/train_metrics.json")
    print(f"Saved best checkpoint to {best_path}")
    print(f"Test accuracy: {test_metrics['accuracy']:.4f}")
    print("Saved training metrics to results/train_metrics.json")


if __name__ == "__main__":
    main()
