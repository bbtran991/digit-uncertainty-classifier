# Digit Classifier That Knows When It Is Unsure

This is a Machine Learning final project about **selective prediction** for handwritten digit recognition. A normal CNN predicts one of the digits 0 through 9 for every input. This version also estimates uncertainty using **Monte Carlo Dropout** and can return **UNCERTAIN** when the input is noisy, ambiguous, corrupted, or out-of-distribution.

The project follows the proposal and progress report:

- Train a CNN on MNIST digit images.
- At inference time, keep dropout active and run the same image through the model 30 times.
- Average the softmax probabilities for the final digit prediction.
- Use predictive variance across the 30 predictions as the uncertainty score.
- If uncertainty is above a threshold, abstain and output `UNCERTAIN`.
- Compare the uncertainty-aware classifier with a baseline CNN that always predicts a digit.

## Repository structure

```text
.
├── train.py              # Train CNN on MNIST and save checkpoint
├── evaluate.py           # Evaluate clean accuracy, selective accuracy, and rejection rates
├── demo.py               # Demo one clean, corrupted, random-noise, or external image
├── requirements.txt      # Required Python packages
├── src/
│   ├── model.py          # CNN architecture with dropout
│   ├── data.py           # MNIST loading plus noise/corruption helpers
│   ├── uncertainty.py    # Monte Carlo Dropout uncertainty code
│   └── utils.py          # Checkpoint, seed, JSON, and device utilities
├── checkpoints/          # Saved model checkpoint goes here after training
└── results/              # Metrics and demo images are saved here
```

## Setup

Create and activate a virtual environment:

```bash
python -m venv .venv
source .venv/bin/activate      # macOS/Linux
# .venv\Scripts\activate       # Windows PowerShell
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## How to run

### 1. Train the CNN

```bash
python train.py --epochs 5 --batch-size 128
```

The first run downloads MNIST into `data/`. The best checkpoint is saved to:

```text
checkpoints/model.pt
```

Training metrics are saved to:

```text
results/train_metrics.json
```

### 2. Evaluate the uncertainty-aware classifier

Use automatic threshold calibration from the validation set:

```bash
python evaluate.py --checkpoint checkpoints/model.pt --auto-threshold
```

Or use a fixed threshold:

```bash
python evaluate.py --checkpoint checkpoints/model.pt --threshold 0.02
```

The evaluation reports:

- normal clean MNIST accuracy,
- coverage, meaning how many clean samples were accepted instead of rejected,
- selective accuracy on accepted samples,
- rejection rate on random noise,
- rejection rate on corrupted digit-like inputs.

Evaluation results are saved to:

```text
results/evaluation.json
```

### 3. Run the demo

Clean MNIST digit:

```bash
python demo.py --checkpoint checkpoints/model.pt --sample clean --index 0
```

Corrupted/ambiguous MNIST digit:

```bash
python demo.py --checkpoint checkpoints/model.pt --sample corrupt --index 0
```

Random noise image:

```bash
python demo.py --checkpoint checkpoints/model.pt --sample noise
```

Your own image:

```bash
python demo.py --checkpoint checkpoints/model.pt --image path/to/my_digit.png
```

The demo prints:

- baseline CNN prediction,
- MC Dropout mean prediction,
- confidence,
- uncertainty score,
- entropy,
- top-1/top-2 margin,
- final decision: digit or `UNCERTAIN`.

It also saves a visualization to:

```text
results/demo_output.png
```

## Main training, inference, and demo code

- **Training:** `train.py`
- **Model definition:** `src/model.py`
- **Uncertainty inference:** `src/uncertainty.py`
- **Evaluation experiments:** `evaluate.py`
- **Demo:** `demo.py`

## Method explanation

The model is a convolutional neural network with dropout layers. During normal training, dropout randomly disables some activations, which helps regularization. During inference, dropout is usually turned off. In this project, dropout is intentionally kept on during inference. The same input image is passed through the model 30 times, producing 30 probability distributions.

If the model is confident, the 30 predictions should mostly agree. If the input is ambiguous or unlike MNIST, the predictions should disagree more. The code measures this disagreement with predictive variance. A high variance means the model is unsure, so the system returns `UNCERTAIN` instead of forcing a digit prediction.

## Results to report after running

Fill this table with the values printed by `evaluate.py` or found in `results/evaluation.json`:

| Metric | Value |
|---|---:|
| Clean MNIST accuracy, all predictions | TODO |
| Coverage on clean digits | TODO |
| Selective accuracy on accepted clean digits | TODO |
| Clean rejection rate | TODO |
| Random noise rejection rate | TODO |
| Corrupted digit rejection rate | TODO |

## Notes about reproducibility

- Default random seed: `42`
- Default MC Dropout passes: `30`
- Default threshold: `0.02`, or use `--auto-threshold` for validation-based calibration
- MNIST is downloaded automatically by TorchVision on the first run

## GitHub submission instructions

1. Create a new GitHub repository, for example `digit-uncertainty-classifier`.
2. Upload all files in this folder.
3. Run training and evaluation at least once.
4. Commit the code, README, and optionally the small JSON result files.
5. Do not commit the downloaded `data/` folder.
6. Submit the repository URL, for example:

```text
https://github.com/YOUR-USERNAME/digit-uncertainty-classifier
```
